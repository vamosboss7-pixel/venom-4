"use client"

import { X, ChevronDown, MoreVertical, Zap } from "lucide-react"

export function GameHeader() {
  return (
    <header className="flex items-center gap-3 bg-header px-4 py-3 text-header-foreground">
      <button type="button" aria-label="ዝጋ" className="rounded-md p-1 transition-opacity hover:opacity-70">
        <X className="h-6 w-6" strokeWidth={2.2} />
      </button>

      <h1 className="flex flex-1 items-center gap-2 pl-2 text-xl font-bold tracking-wide">
        Flash Bingo
        <Zap className="h-6 w-6 fill-flash-yellow text-flash-yellow" />
      </h1>

      <button type="button" aria-label="ዝርዝር ክፈት" className="rounded-md p-1 transition-opacity hover:opacity-70">
        <ChevronDown className="h-6 w-6" strokeWidth={2.2} />
      </button>
      <button type="button" aria-label="ተጨማሪ" className="rounded-md p-1 transition-opacity hover:opacity-70">
        <MoreVertical className="h-6 w-6" strokeWidth={2.2} />
      </button>
    </header>
  )
}
