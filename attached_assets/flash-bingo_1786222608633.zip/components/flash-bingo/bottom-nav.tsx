"use client"

import { Grid3x3, Wallet } from "lucide-react"
import { cn } from "@/lib/utils"

type BottomNavProps = {
  active: "bingo" | "wallet"
  onChange: (tab: "bingo" | "wallet") => void
}

export function BottomNav({ active, onChange }: BottomNavProps) {
  return (
    <nav className="flex items-stretch border-t border-cell-border bg-nav">
      <button
        type="button"
        onClick={() => onChange("bingo")}
        className={cn(
          "flex flex-1 flex-col items-center gap-1 py-2.5 text-sm font-bold transition-colors",
          active === "bingo" ? "text-flash-yellow" : "text-foreground/60",
        )}
      >
        <Grid3x3 className="h-5 w-5" />
        BINGO
      </button>
      <button
        type="button"
        onClick={() => onChange("wallet")}
        className={cn(
          "flex flex-1 flex-col items-center gap-1 py-2.5 text-sm font-medium transition-colors",
          active === "wallet" ? "text-flash-yellow" : "text-foreground/60",
        )}
      >
        <Wallet className="h-5 w-5" />
        WALLET
      </button>
    </nav>
  )
}
