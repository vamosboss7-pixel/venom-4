"use client"

import { VolumeX, Volume2 } from "lucide-react"

const LETTERS = ["B", "I", "N", "G", "O"] as const

function letterFor(n: number) {
  return LETTERS[Math.floor((n - 1) / 15)] ?? "B"
}

type CalledPanelProps = {
  current: number | null
  gameId: string
  pot: number
  muted: boolean
  onToggleMute: () => void
  callIndex: number
  totalCalls: number
}

export function CalledPanel({
  current,
  gameId,
  pot,
  muted,
  onToggleMute,
  callIndex,
  totalCalls,
}: CalledPanelProps) {
  return (
    <div className="flex items-center gap-3 rounded-xl border border-cell-border/70 bg-header/40 p-3">
      {/* big called ball */}
      <div className="relative flex h-[88px] w-[88px] shrink-0 flex-col items-center justify-center rounded-full bg-gradient-to-b from-flash-yellow to-[oklch(0.72_0.17_75)] text-header shadow-lg">
        <span className="absolute top-3 text-xs font-bold">{current ? letterFor(current) : ""}</span>
        <span className="text-4xl font-extrabold tabular-nums leading-none">{current ?? "-"}</span>
      </div>

      {/* divider */}
      <div className="h-20 w-px bg-cell-border/50" />

      {/* pot info */}
      <div className="flex min-w-0 flex-1 flex-col gap-1">
        <div className="flex items-center gap-2">
          <span className="text-lg font-bold text-foreground">ደራሹ</span>
          <span className="truncate rounded-md border border-cell-border bg-header px-2 py-0.5 text-sm font-bold text-foreground">
            {gameId}
          </span>
        </div>
        <div className="flex items-baseline gap-1">
          <span className="text-2xl font-extrabold tabular-nums text-foreground">{pot.toFixed(2)}</span>
          <span className="text-sm text-foreground/70">ብር</span>
        </div>
      </div>

      {/* mute + call counter */}
      <div className="flex flex-col items-center gap-2">
        <button
          type="button"
          onClick={onToggleMute}
          aria-label={muted ? "ድምጽ አብራ" : "ድምጽ አጥፋ"}
          className="rounded-md border border-cell-border bg-header p-1.5 text-foreground/80 transition-opacity hover:opacity-70"
        >
          {muted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
        </button>
        <div className="flex flex-col items-center leading-none">
          <span className="text-base font-bold text-foreground">ጥሪ</span>
          <span className="text-sm font-semibold tabular-nums text-foreground/80">
            {callIndex}/{totalCalls}
          </span>
        </div>
      </div>
    </div>
  )
}
