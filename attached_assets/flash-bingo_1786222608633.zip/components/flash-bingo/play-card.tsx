"use client"

import { Star } from "lucide-react"
import { cn } from "@/lib/utils"

const LETTERS = ["B", "I", "N", "G", "O"] as const

type PlayCardProps = {
  id: number
  // 25 cells in row-major order; center (index 12) is "star"
  grid: (number | "star")[]
  called: Set<number>
}

export function PlayCard({ id, grid, called }: PlayCardProps) {
  return (
    <div className="flex-1 rounded-xl border border-flash-green/50 bg-gradient-to-b from-board-from to-board-to p-2">
      <p className="mb-1 text-center text-sm font-extrabold tracking-wide text-flash-yellow">CARD #{id}</p>

      {/* column letters */}
      <div className="mb-1 grid grid-cols-5 gap-1">
        {LETTERS.map((l) => (
          <span key={l} className="text-center text-sm font-extrabold text-foreground">
            {l}
          </span>
        ))}
      </div>

      {/* 5x5 grid */}
      <div className="grid grid-cols-5 gap-1">
        {grid.map((cell, i) => {
          if (cell === "star") {
            return (
              <div
                key={i}
                className="flex aspect-square items-center justify-center rounded-md bg-flash-yellow"
              >
                <Star className="h-4 w-4 fill-header text-header" />
              </div>
            )
          }
          const marked = called.has(cell)
          return (
            <div
              key={i}
              className={cn(
                "flex aspect-square items-center justify-center rounded-md border text-sm font-bold tabular-nums transition-colors",
                marked
                  ? "border-flash-green bg-flash-green text-header"
                  : "border-cell-border/60 bg-cell text-foreground",
              )}
            >
              {cell}
            </div>
          )
        })}
      </div>
    </div>
  )
}
