"use client"

import { Volume2, VolumeX } from "lucide-react"

type TitleBarProps = {
  muted: boolean
  onToggleMute: () => void
  countdown: number
}

export function TitleBar({ muted, onToggleMute, countdown }: TitleBarProps) {
  return (
    <div className="px-3 pt-4">
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={onToggleMute}
          aria-label={muted ? "ድምፅ አብራ" : "ድምፅ ዝጋ"}
          aria-pressed={muted}
          className="flex h-11 w-11 items-center justify-center rounded-lg border border-cell-border bg-cell"
        >
          {muted ? (
            <VolumeX className="h-6 w-6 text-destructive" />
          ) : (
            <Volume2 className="h-6 w-6 text-flash-green" />
          )}
        </button>

        <h2 className="text-2xl font-extrabold tracking-wider">
          <span className="text-flash-yellow">FLASH</span>
          <span className="text-foreground/50"> • </span>
          <span className="text-flash-green">BINGO</span>
        </h2>

        <div
          className="flex h-12 w-12 items-center justify-center rounded-lg border-2 border-flash-yellow text-xl font-extrabold text-flash-yellow shadow-[0_0_14px_-2px] shadow-flash-yellow/50"
          aria-label={`ቀሪ ጊዜ ${countdown} ሰከንድ`}
        >
          {countdown}
        </div>
      </div>
      <div className="mt-3 h-px w-full bg-cell-border" />
    </div>
  )
}
