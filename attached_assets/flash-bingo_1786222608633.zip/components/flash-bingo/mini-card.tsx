"use client"

import { Star } from "lucide-react"

type MiniCardProps = {
  id: number
  grid: (number | "star")[]
}

export function MiniCard({ id, grid }: MiniCardProps) {
  return (
    <div className="w-[132px] shrink-0 rounded-lg border border-flash-green/60 bg-header/95 p-1.5 shadow-lg">
      <div className="mb-1 flex items-center justify-between">
        <span className="text-xs font-extrabold text-flash-green">BINGO</span>
        <span className="rounded bg-flash-green px-1.5 text-xs font-bold text-header">#{id}</span>
      </div>
      <div className="grid grid-cols-5 gap-[3px]">
        {grid.map((cell, i) =>
          cell === "star" ? (
            <div
              key={i}
              className="flex aspect-square items-center justify-center rounded-[3px] bg-flash-yellow"
            >
              <Star className="h-3 w-3 fill-header text-header" />
            </div>
          ) : (
            <div
              key={i}
              className="flex aspect-square items-center justify-center rounded-[3px] bg-cell text-[9px] font-semibold text-foreground"
            >
              {cell}
            </div>
          ),
        )}
      </div>
    </div>
  )
}
