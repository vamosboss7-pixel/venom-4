"use client"

import { cn } from "@/lib/utils"

type NumberGridProps = {
  total: number
  selected: Set<number>
  taken: Set<number>
  onToggle: (n: number) => void
  atLimit?: boolean
}

export function NumberGrid({ total, selected, taken, onToggle, atLimit = false }: NumberGridProps) {
  const numbers = Array.from({ length: total }, (_, i) => i + 1)

  return (
    <div className="grid grid-cols-7 gap-2 px-3 py-4">
      {numbers.map((n) => {
        const isSelected = selected.has(n)
        const isTaken = taken.has(n) && !isSelected
        // once the max is reached, un-selected free cells can't be picked
        const isLocked = atLimit && !isSelected && !isTaken

        return (
          <button
            key={n}
            type="button"
            disabled={isTaken || isLocked}
            onClick={() => onToggle(n)}
            aria-pressed={isSelected}
            aria-label={`ቁጥር ${n}${isSelected ? ", ተመርጧል" : isTaken ? ", ተይዟል" : ""}`}
            className={cn(
              "flex aspect-square items-center justify-center rounded-lg text-base font-bold transition-all duration-150",
              "focus:outline-none focus-visible:ring-2 focus-visible:ring-flash-yellow",
              isSelected
                ? "bg-flash-yellow text-header shadow-[0_0_16px_-2px] shadow-flash-yellow/70"
                : isTaken
                  ? "bg-taken text-taken-foreground line-through"
                  : isLocked
                    ? "border border-cell-border/40 bg-cell/40 text-foreground/30"
                    : "border border-cell-border bg-cell text-foreground active:scale-95 active:border-flash-green",
            )}
          >
            {n}
          </button>
        )
      })}
    </div>
  )
}
