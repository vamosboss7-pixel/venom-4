"use client"

import { cn } from "@/lib/utils"

const LETTERS = ["B", "I", "N", "G", "O"] as const

type CalledBoardProps = {
  called: Set<number>
  latest: number | null
}

// B:1-15, I:16-30, N:31-45, G:46-60, O:61-75
export function CalledBoard({ called, latest }: CalledBoardProps) {
  return (
    <div className="rounded-xl border border-cell-border/70 bg-header/40 p-2">
      <div className="flex flex-col gap-1">
        {LETTERS.map((letter, row) => {
          const start = row * 15 + 1
          const nums = Array.from({ length: 15 }, (_, i) => start + i)
          return (
            <div key={letter} className="flex items-center gap-1.5">
              <span className="w-4 shrink-0 text-center text-lg font-extrabold text-foreground">{letter}</span>
              <div className="flex flex-1 justify-between gap-[3px]">
                {nums.map((n) => {
                  const isCalled = called.has(n)
                  const isLatest = latest === n
                  return (
                    <span
                      key={n}
                      className={cn(
                        "flex h-5 flex-1 items-center justify-center rounded-full border text-[10px] font-semibold tabular-nums transition-colors",
                        isLatest
                          ? "border-flash-yellow bg-flash-yellow text-header"
                          : isCalled
                            ? "border-flash-green/70 bg-flash-green/25 text-foreground"
                            : "border-cell-border/40 bg-transparent text-foreground/35",
                      )}
                    >
                      {n}
                    </span>
                  )
                })}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
