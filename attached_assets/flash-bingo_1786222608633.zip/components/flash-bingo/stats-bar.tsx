"use client"

import { Gamepad2, Trophy } from "lucide-react"

type StatsBarProps = {
  play: number
  pot: number
  cardsTaken: number
  win: number
}

function format(n: number) {
  return n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
}

export function StatsBar({ play, pot, cardsTaken, win }: StatsBarProps) {
  return (
    <div className="grid grid-cols-[1fr_1.15fr_1fr] items-stretch gap-3 px-3 pt-4">
      {/* PLAY */}
      <div className="flex flex-col justify-center rounded-xl border border-flash-yellow/40 bg-cell px-3 py-2.5">
        <div className="flex items-center gap-1.5 text-sm font-bold">
          <Gamepad2 className="h-5 w-5 text-flash-green" />
          <span>PLAY</span>
        </div>
        <span className="mt-0.5 text-xl font-extrabold leading-none">{format(play)}</span>
      </div>

      {/* POT / ደራሹ */}
      <div className="flex flex-col items-center justify-center rounded-xl border-2 border-flash-yellow/70 bg-cell px-2 py-2 text-center shadow-[0_0_18px_-4px] shadow-flash-yellow/40">
        <span className="text-sm font-semibold text-foreground/80">ደራሹ</span>
        <span className="text-2xl font-extrabold leading-tight text-flash-yellow">{format(pot)}</span>
        <span className="mt-0.5 text-[13px] font-medium text-foreground/90">
          የተያዙ ካርዶች: {cardsTaken}
        </span>
      </div>

      {/* WIN */}
      <div className="flex flex-col justify-center rounded-xl border border-flash-yellow/40 bg-cell px-3 py-2.5">
        <div className="flex items-center justify-end gap-1.5 text-sm font-bold">
          <Trophy className="h-5 w-5 text-flash-yellow" />
          <span>WIN</span>
        </div>
        <span className="mt-0.5 text-right text-xl font-extrabold leading-none">{format(win)}</span>
      </div>
    </div>
  )
}
