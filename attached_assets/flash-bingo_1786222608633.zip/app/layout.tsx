import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Noto_Sans_Ethiopic } from 'next/font/google'
import './globals.css'

const notoEthiopic = Noto_Sans_Ethiopic({
  subsets: ['ethiopic', 'latin'],
  weight: ['400', '500', '600', '700', '800'],
  variable: '--font-noto-ethiopic',
})

export const metadata: Metadata = {
  title: 'Flash Bingo ⚡',
  description: 'Flash Bingo - fast-paced number bingo game',
  generator: 'v0.app',
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#1b2431',
  userScalable: false,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${notoEthiopic.variable} bg-header`}>
      <body className="antialiased font-sans">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
