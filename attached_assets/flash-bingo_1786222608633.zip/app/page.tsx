"use client"

import { useEffect, useMemo, useRef, useState } from "react"
import { useRouter } from "next/navigation"
import { GameHeader } from "@/components/flash-bingo/game-header"
import { StatsBar } from "@/components/flash-bingo/stats-bar"
import { TitleBar } from "@/components/flash-bingo/title-bar"
import { NumberGrid } from "@/components/flash-bingo/number-grid"
import { MiniCard } from "@/components/flash-bingo/mini-card"
import { BottomNav } from "@/components/flash-bingo/bottom-nav"

const TOTAL_NUMBERS = 150
const STAKE = 4 // ብር per card
const COUNTDOWN_START = 50
const MAX_CARDS = 4

// deterministic 5x5 bingo card for a given id (center is a free star)
function buildCard(id: number): (number | "star")[] {
  const cells: (number | "star")[] = []
  let seed = id * 9301 + 49297
  const rand = () => {
    seed = (seed * 9301 + 49297) % 233280
    return seed / 233280
  }
  for (let i = 0; i < 25; i++) {
    if (i === 12) {
      cells.push("star")
    } else {
      cells.push(1 + Math.floor(rand() * 75))
    }
  }
  return cells
}

export default function FlashBingoPage() {
  const router = useRouter()
  const [selected, setSelected] = useState<Set<number>>(new Set())
  const [muted, setMuted] = useState(true)
  const [countdown, setCountdown] = useState(COUNTDOWN_START)
  const [tab, setTab] = useState<"bingo" | "wallet">("bingo")

  // keep latest selection available to the timer without resetting it
  const selectedRef = useRef(selected)
  selectedRef.current = selected
  const startedRef = useRef(false)

  // transient warning shown when the player tries to exceed the card limit
  const [showLimitWarning, setShowLimitWarning] = useState(false)
  const warnTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const warnLimit = () => {
    setShowLimitWarning(true)
    if (warnTimerRef.current) clearTimeout(warnTimerRef.current)
    warnTimerRef.current = setTimeout(() => setShowLimitWarning(false), 2500)
  }
  useEffect(() => () => {
    if (warnTimerRef.current) clearTimeout(warnTimerRef.current)
  }, [])

  // numbers already taken by other players (static demo set)
  const taken = useMemo(() => {
    const s = new Set<number>()
    const seedList = [66, 68, 70, 73, 80, 83, 85, 87, 89, 91, 93, 95, 98, 101, 104, 107, 110, 112, 115, 119, 121, 124, 126, 131, 133, 137, 139]
    seedList.forEach((n) => s.add(n))
    return s
  }, [])

  useEffect(() => {
    const t = setInterval(() => {
      setCountdown((c) => {
        if (c <= 1) {
          const picks = [...selectedRef.current]
          if (picks.length > 0 && !startedRef.current) {
            // timer finished with cards selected -> start the game
            startedRef.current = true
            clearInterval(t)
            router.push(`/play?cards=${picks.join(",")}`)
            return 0
          }
          // no cards selected yet -> keep waiting for the next round
          return COUNTDOWN_START
        }
        return c - 1
      })
    }, 1000)
    return () => clearInterval(t)
  }, [router])

  const toggle = (n: number) => {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(n)) {
        next.delete(n)
      } else {
        // limit selection to a maximum of 4 cards
        if (next.size >= MAX_CARDS) {
          warnLimit()
          return prev
        }
        next.add(n)
      }
      return next
    })
  }

  const cardsTaken = taken.size + selected.size
  const pot = cardsTaken * 40
  const play = selected.size * STAKE
  const selectedList = [...selected].sort((a, b) => a - b)

  return (
    <main className="mx-auto flex h-dvh max-w-md flex-col overflow-hidden bg-header">
      <GameHeader />

      {/* board */}
      <div className="relative flex flex-1 flex-col overflow-hidden bg-gradient-to-b from-board-from to-board-to">
        <StatsBar play={play} pot={pot} cardsTaken={cardsTaken} win={0} />
        <TitleBar muted={muted} onToggleMute={() => setMuted((m) => !m)} countdown={countdown} />

        <div className="min-h-0 flex-1 overflow-y-auto">
          <NumberGrid
            total={TOTAL_NUMBERS}
            selected={selected}
            taken={taken}
            onToggle={toggle}
            atLimit={selected.size >= MAX_CARDS}
          />
        </div>

        {/* selected card previews */}
        {selectedList.length > 0 && (
          <div className="pointer-events-none absolute bottom-0 left-0 right-0 flex gap-2 overflow-x-auto p-3">
            {selectedList.slice(0, 4).map((id) => (
              <MiniCard key={id} id={id} grid={buildCard(id)} />
            ))}
          </div>
        )}
      </div>

      {/* max-card warning */}
      {showLimitWarning && (
        <div
          role="alert"
          aria-live="assertive"
          className="pointer-events-none fixed inset-x-0 top-40 z-[60] flex justify-center px-4"
        >
          <div className="flex items-center gap-2 rounded-xl border border-flash-yellow/60 bg-header/95 px-4 py-3 text-center text-sm font-semibold text-flash-yellow shadow-lg backdrop-blur-sm animate-in fade-in slide-in-from-top-2">
            <span aria-hidden className="text-base leading-none">
              !
            </span>
            ከ4 ካርድ በላይ መምረጥ አይችሉም
          </div>
        </div>
      )}

      <BottomNav active={tab} onChange={setTab} />
    </main>
  )
}
