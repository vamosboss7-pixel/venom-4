"use client"

import { Suspense, useEffect, useMemo, useState } from "react"
import { useSearchParams } from "next/navigation"
import { GameHeader } from "@/components/flash-bingo/game-header"
import { CalledBoard } from "@/components/flash-bingo/called-board"
import { CalledPanel } from "@/components/flash-bingo/called-panel"
import { PlayCard } from "@/components/flash-bingo/play-card"
import { BottomNav } from "@/components/flash-bingo/bottom-nav"

const TOTAL_CALLS = 75
const CALL_INTERVAL = 3000 // ms between draws
const GAME_ID = "#86195"
const POT = 2368

// Build a valid bingo card (row-major) with proper column ranges:
// B:1-15, I:16-30, N:31-45, G:46-60, O:61-75. Center is a free star.
function buildCard(id: number): (number | "star")[] {
  let seed = id * 9301 + 49297
  const rand = () => {
    seed = (seed * 9301 + 49297) % 233280
    return seed / 233280
  }
  // pick 5 unique numbers per column
  const columns: number[][] = []
  for (let c = 0; c < 5; c++) {
    const min = c * 15 + 1
    const pool = Array.from({ length: 15 }, (_, i) => min + i)
    // shuffle
    for (let i = pool.length - 1; i > 0; i--) {
      const j = Math.floor(rand() * (i + 1))
      ;[pool[i], pool[j]] = [pool[j], pool[i]]
    }
    columns.push(pool.slice(0, 5))
  }
  // assemble row-major
  const cells: (number | "star")[] = []
  for (let r = 0; r < 5; r++) {
    for (let c = 0; c < 5; c++) {
      if (r === 2 && c === 2) cells.push("star")
      else cells.push(columns[c][r])
    }
  }
  return cells
}

export default function PlayPage() {
  return (
    <Suspense fallback={<main className="h-dvh bg-header" />}>
      <PlayScreen />
    </Suspense>
  )
}

function PlayScreen() {
  const searchParams = useSearchParams()
  const [muted, setMuted] = useState(true)
  const [tab, setTab] = useState<"bingo" | "wallet">("bingo")
  const [sequence] = useState<number[]>(() => {
    // deterministic draw order 1..75 shuffled
    const arr = Array.from({ length: TOTAL_CALLS }, (_, i) => i + 1)
    let seed = 12345
    const rand = () => {
      seed = (seed * 9301 + 49297) % 233280
      return seed / 233280
    }
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(rand() * (i + 1))
      ;[arr[i], arr[j]] = [arr[j], arr[i]]
    }
    return arr
  })
  const [drawn, setDrawn] = useState(1) // how many numbers have been called

  const cards = useMemo(() => {
    const raw = searchParams.get("cards")
    const ids = raw
      ? raw
          .split(",")
          .map((n) => Number.parseInt(n, 10))
          .filter((n) => Number.isFinite(n))
      : [75, 79]
    return ids.map((id) => ({ id, grid: buildCard(id) }))
  }, [searchParams])

  useEffect(() => {
    if (drawn >= TOTAL_CALLS) return
    const t = setTimeout(() => setDrawn((d) => Math.min(d + 1, TOTAL_CALLS)), CALL_INTERVAL)
    return () => clearTimeout(t)
  }, [drawn])

  const called = useMemo(() => new Set(sequence.slice(0, drawn)), [sequence, drawn])
  const current = drawn > 0 ? sequence[drawn - 1] : null

  return (
    <main className="mx-auto flex h-dvh max-w-md flex-col overflow-hidden bg-header">
      <GameHeader />

      <div className="flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto bg-gradient-to-b from-board-from to-board-to p-3">
        <CalledBoard called={called} latest={current} />

        <CalledPanel
          current={current}
          gameId={GAME_ID}
          pot={POT}
          muted={muted}
          onToggleMute={() => setMuted((m) => !m)}
          callIndex={drawn}
          totalCalls={TOTAL_CALLS}
        />

        <div className="grid grid-cols-2 gap-3">
          {cards.map((c) => (
            <PlayCard key={c.id} id={c.id} grid={c.grid} called={called} />
          ))}
        </div>
      </div>

      <BottomNav active={tab} onChange={setTab} />
    </main>
  )
}
